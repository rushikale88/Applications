#include<stdio.h>

int main()  // Program execution starts from here
{
    printf("Jay Ganesh...\n");

    return 0;
}