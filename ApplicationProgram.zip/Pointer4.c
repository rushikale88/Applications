#include<stdio.h>

int main()
{
    int Arr[5] = {10,20,30,40,50};

    int *p = &(Arr[1]);
    int *q = &(Arr[3]);


    return 0;
}
