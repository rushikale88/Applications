
class Marvellous    
{
    public int No1;
    public int No2;
}

class HashCodeDemo  
{
    public static void main(String A[])
    {
        Marvellous mobj = new Marvellous();
        System.out.println("Hascode of mobj is : "+mobj.hashCode());
    }
}