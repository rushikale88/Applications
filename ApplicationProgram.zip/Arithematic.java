package Marvellous;

public class Arithematic
{
    public int Addition(int A, int B)
    {
        return A+B;
    }
    public int Substraction(int A, int B)
    {
        return A-B;
    }
}

// javac -d . Arithematic.java

// javac                Name of java compiler
// -d                   Create Directory (Folder)
// .                    Current directory (Jithe .java file ahe tyach folder madhe)
// Arithematic.java     Name of java file