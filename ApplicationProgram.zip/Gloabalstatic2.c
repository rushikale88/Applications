

int A = 11;

static int B = 11;
