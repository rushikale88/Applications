class Multi
{
    public static void main(String arg[]) throws Exception
    {
            try
            {
            }
            catch(IOException iobj)
            {
            }
            catch(ArithematicException aobj)
            {
            }
            catch(ArryIndexOutOfBounds arobj)
            {
            }
            catch(Exception obj)
            {
            }
    }
}