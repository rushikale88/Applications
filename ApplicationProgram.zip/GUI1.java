import java.awt.*;

class GUI1
{
    public static void main(String a[])
    {
        Frame fobj = new Frame("Marvellous");

        fobj.setSize(500,200);
        fobj.setVisible(true);
    }
}