#include<stdio.h>

int main()
{
    int Amit = 23;
    int Pooja = 24;
    int Sagar = 20;
    int Rupali = 22;
    int Ram = 19;

    int Age[5] = {23,24,20,22,19};


    printf("%d\n",Sagar);

    printf("%d\n",Age[0]);
    printf("%d\n",Age[1]);    
    printf("%d\n",Age[2]);
    printf("%d\n",Age[3]);
    printf("%d\n",Age[4]);

    return 0;
}