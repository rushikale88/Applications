#include<stdio.h>

int main()
{
    register int iCnt = 0;

    for(iCnt = 0; iCnt < 4; iCnt++)
    {
        printf("Jay Ganesh...\n");
    }
    
    return 0;
}