#include<stdio.h>

int Y;
int Z = 10;     // Global variable

int main()
{
    int A = 10;
    int B;
    auto int C = 10;
    auto int D;


    return 0;
}