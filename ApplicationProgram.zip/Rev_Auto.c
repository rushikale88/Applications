#include<stdio.h>

int no = 11;

void Fun()
{
  int i = 11;


}

int main()
{
  auto int j = 11;
  int x = 0;

  return 0;
}