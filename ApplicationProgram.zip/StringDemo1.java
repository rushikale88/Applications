
class StringDemo1
{
    public static void main(String A[])
    {
        String str1 = "Hello";
        String str2 = new String("Hello");
        String str3 = "Demo";
        String str4 = new String("Hello");
        String str5 = new String("Demo");
        String str6 = "PPA";
        String str7 = "Hello";
    }
}