#include<stdio.h>

void Fun()
{
  register int i = 11;


}

int main()
{
  register int i = 11;


  return 0;
}